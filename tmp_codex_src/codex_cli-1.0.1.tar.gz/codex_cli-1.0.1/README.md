# Codex CLI Tool

A powerful CLI tool that integrates with the OpenAI and Gemini APIs to assist with code generation, debugging, and much more.

## Installation

To install this tool, run:

```bash
pip install codex_cli
